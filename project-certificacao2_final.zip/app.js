/* app.js - UI logic com validações e formatação textual */

function parseNotas(text) {
  if (!text) return [];
  // aceita vírgula como separador e tanto '.' quanto ',' como decimal
  return text.split(',')
    .map(s => s.trim().replace(',', '.'))
    .map(Number)
    .filter(n => Number.isFinite(n));
}

function notasValidas(notas) {
  // notas devem estar entre 0 e 10 inclusive
  return notas.every(n => Number.isFinite(n) && n >= 0 && n <= 10);
}

function formatNumberBR(n, digits=8) {
  if (!Number.isFinite(n)) return 'NaN';
  // mantemos a saída com vírgula decimal como no exemplo
  const s = Number(n).toFixed(digits);
  return s.replace('.', ',');
}

function renderResultado(atleta) {
  const nome = atleta.obtemNomeAtleta();
  const idade = atleta.obtemIdadeAtleta();
  const peso = atleta.obtemPesoAtleta();
  const altura = atleta.altura;
  const notas = atleta.obtemNotasAtleta();
  const categoria = atleta.obtemCategoria();
  const imc = atleta.obtemIMC();
  const media = atleta.obtemMediaValida();

  const notasStr = notas.join(',');

  const imcStr = Number.isFinite(imc) ? imc : NaN;
  const mediaStr = formatNumberBR(media, 8);

  return [
    `Nome: ${nome}`,
    `Idade: ${idade}`,
    `Peso: ${peso}`,
    `Altura: ${altura}`,
    `Notas: ${notasStr}`,
    `Categoria: ${categoria}`,
    `IMC: ${imcStr}`,
    `Média válida: ${mediaStr}`
  ].join('\n');
}

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('atletaForm');
  const resultado = document.getElementById('resultado');
  const exemploBtn = document.getElementById('exemploBtn');
  const limparBtn = document.getElementById('limparBtn');
  const errosDiv = document.getElementById('erros');

  function showErros(msg) {
    errosDiv.textContent = msg || '';
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    showErros('');
    resultado.textContent = '';

    const nome = document.getElementById('nome').value.trim();
    const idadeVal = document.getElementById('idade').value;
    const pesoVal = document.getElementById('peso').value;
    const alturaVal = document.getElementById('altura').value;
    const notasText = document.getElementById('notas').value;

    // validações básicas de presença
    const erros = [];
    if (!nome) erros.push('Informe o nome do atleta.');
    const idade = Number(idadeVal);
    if (!idadeVal || !Number.isFinite(idade) || idade < 0 || idade > 150) erros.push('Idade inválida.');
    const peso = Number(pesoVal);
    if (!pesoVal || !Number.isFinite(peso) || peso <= 0) erros.push('Peso inválido.');
    const altura = Number(alturaVal);
    if (!alturaVal || !Number.isFinite(altura) || altura <= 0) erros.push('Altura inválida.');

    const notas = parseNotas(notasText);
    if (notas.length === 0) erros.push('Informe pelo menos uma nota válida (0 a 10).');
    if (!notasValidas(notas)) erros.push('As notas devem estar entre 0 e 10 (use vírgula para separar).');

    if (erros.length) {
      showErros(erros.join(' '));
      return;
    }

    // criar atleta e exibir
    const atleta = new Atleta(nome, idade, peso, altura, notas);
    resultado.textContent = renderResultado(atleta);
  });

  exemploBtn.addEventListener('click', () => {
    document.getElementById('nome').value = 'Cesar Abascal';
    document.getElementById('idade').value = '30';
    document.getElementById('peso').value = '80';
    document.getElementById('altura').value = '1.7';
    document.getElementById('notas').value = '10,9.34,8.42,10,7.88';
    showErros('');
    document.getElementById('nome').focus();
  });

  limparBtn.addEventListener('click', () => {
    form.reset();
    resultado.textContent = '';
    showErros('');
  });
});