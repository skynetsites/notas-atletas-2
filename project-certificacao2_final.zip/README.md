# Projeto de Certificação 2 — Dados dos Atletas (Final)

Descrição
- Projeto em HTML + JavaScript puro (rodando no navegador), com CSS responsivo.
- Implementa a classe `Atleta` e os métodos solicitados: calculaCategoria, calculaIMC, calculaMediaValida e os getters.
- Exibição no formato texto (igual ao exemplo do enunciado).

Validações implementadas
- Campos obrigatórios: nome, idade, peso, altura, notas.
- Idade: 0 a 150 anos.
- Peso: > 0.
- Altura: > 0.
- Notas: pelo menos 1 nota válida; cada nota deve estar entre 0 e 10 (inclusive). Separar por vírgula.

Média válida
- Se houver 3 ou mais notas, remove-se a menor e a maior nota e calcula-se a média das demais.
- Se houver menos de 3 notas, calcula-se a média simples.

Uso
1. Abra `index.html` no navegador.
2. Preencha os campos e clique em "Calcular".
3. Use "Carregar Exemplo" para preencher automaticamente com o exemplo do enunciado.

Arquivos
- `index.html`
- `styles.css`
- `atleta.js`
- `app.js`
