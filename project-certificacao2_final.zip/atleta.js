/**
 * Classe Atleta
 * Recebe: nome, idade, peso, altura, notas (array de números)
 * Métodos principais:
 *  - calculaCategoria()
 *  - calculaIMC()
 *  - calculaMediaValida()
 *  - getters pedidos pelo enunciado (obtem...)
 */
class Atleta {
  constructor(nome, idade, peso, altura, notas) {
    this.nome = String(nome || "").trim();
    this.idade = Number(idade || 0);
    this.peso = Number(peso || 0);
    this.altura = Number(altura || 0);
    // garante que notas seja um array de números válidos
    this.notas = Array.isArray(notas) ? notas.map(n => Number(n)).filter(Number.isFinite) : [];
  }

  calculaCategoria() {
    const i = this.idade;
    if (i >= 9 && i <= 11) return "Infantil";
    if (i === 12 || i === 13) return "Juvenil";
    if (i === 14 || i === 15) return "Intermediário";
    if (i >= 16 && i <= 30) return "Adulto";
    return "Sem categoria";
  }

  calculaIMC() {
    if (!this.altura || this.altura <= 0) return NaN;
    return this.peso / (this.altura * this.altura);
  }

  calculaMediaValida() {
    const notas = this.notas.slice().filter(Number.isFinite);
    if (notas.length === 0) return NaN;

    if (notas.length < 3) {
      // média simples
      const soma = notas.reduce((s,v) => s+v, 0);
      return soma / notas.length;
    }

    // remove uma menor e uma maior
    const sorted = notas.sort((a,b) => a-b);
    const middle = sorted.slice(1, -1);
    const soma = middle.reduce((s,v) => s+v, 0);
    return soma / middle.length;
  }

  obtemNomeAtleta() { return this.nome; }
  obtemIdadeAtleta() { return this.idade; }
  obtemPesoAtleta() { return this.peso; }
  obtemNotasAtleta() { return this.notas; }
  obtemCategoria() { return this.calculaCategoria(); }
  obtemIMC() { return this.calculaIMC(); }
  obtemMediaValida() { return this.calculaMediaValida(); }
}

// expõe globalmente para o browser
window.Atleta = Atleta;
